Plebum Dominium tools bundle
==============================

Verify this zip before extracting it. Its SHA-256 is printed in VERIFY.md.
One matching hash covers every file inside.

Files
-----
- dice-converter.html: Dice converter page. Records the rolls, prints the 24 words.
- descriptor-tool.html: Descriptor tool page. Encrypts and decrypts the wallet map.
- bip39_dice_converter.py: Dice converter, Python. The second tool for the dice sheet.
- descriptor_obfuscator.py: Descriptor obfuscator, Python. GPG AES-256.
- eff_large_wordlist.txt: EFF Large Wordlist. 7,776 words for dice passphrases.
- hash_checker.html: Hash checker page. The older manual version of the verify page.

Use
---
Copy the files you need to the data USB. The two HTML pages run offline in
Tor Browser on Tails. The Python files run with python3 on Tails.
